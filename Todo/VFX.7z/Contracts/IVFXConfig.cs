﻿namespace Assets.Scripts.Craiel.VFX.Contracts
{
    using Essentials.Contracts;

    public interface IVFXConfig : IComponentConfig
    {
    }
}