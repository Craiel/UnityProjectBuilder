﻿namespace Assets.Scripts.Craiel.VFX
{
    using Craiel.GDX.AI.Sharp.Pool;

    public class VFXPool : GameObjectPool<VFXController>
    {
        // -------------------------------------------------------------------
        // Public
        // -------------------------------------------------------------------
    }
}
