﻿namespace Assets._TheWall.Scripts.Debug.Gyms
{
    using System.Collections.Generic;
    using System.Linq;
    using Abilities;
    using CoreGame.Sys.Resource;
    using Defenses;
    using Entity;
    using Player;
    using Player.Controller;
    using StaticData.Ability;
    using StaticData.Common;
    using UnityEngine;
    using VFX;
    using VFX.Instance;

    public class DebugGymVfx : DebugGymSelectorBase<ActorBase>
    {
        private readonly IList<ActiveVfxTicket> runningEffects;

        // -------------------------------------------------------------------
        // Constructor
        // -------------------------------------------------------------------
        public DebugGymVfx()
        {
            this.runningEffects = new List<ActiveVfxTicket>();
        }

        // -------------------------------------------------------------------
        // Public
        // -------------------------------------------------------------------
        [SerializeField]
        public StaticResourceVFXRef[] EffectsToPlay;

        [SerializeField]
        public VfxTimingParameters TimingParameters;

        [SerializeField]
        public StaticDataAbilityRef[] EffectsToPlayFromAbilities;

        [SerializeField]
        public int SourceGroup = 0;

        [SerializeField]
        public int TargetGroup = 1;

        public bool IsPlaying { get; private set; }

        public void Start()
        {
            VfxSystem.InstantiateAndInitialize();
        }

        public override void Update()
        {
            // Can't do any other action while playing
            if (this.IsPlaying)
            {
                this.UpdateEffects();
                return;
            }

            base.Update();
        }

        public void Execute()
        {
            if (!this.HasActiveSelection || this.IsPlaying)
            {
                return;
            }
            
            this.StartEffects();

            this.IsPlaying = true;
        }

        public void Cancel()
        {
            if (!this.IsPlaying)
            {
                return;
            }

            for (var i = 0; i < this.runningEffects.Count; i++)
            {
                ActiveVfxTicket instance = this.runningEffects[i];
                VfxSystem.Instance.StopEffect(ref instance);
            }

            this.runningEffects.Clear();

            this.IsPlaying = false;
        }

        public void Clear()
        {
            this.EffectsToPlay = new StaticResourceVFXRef[0];
            this.EffectsToPlayFromAbilities = new StaticDataAbilityRef[0];

            this.ClearSelection();
        }

        // -------------------------------------------------------------------
        // Protected
        // -------------------------------------------------------------------
        protected override void DisableSceneBehaviors()
        {
            // this.DisableSceneBehavior<MonsterActor>();

            this.DisableSceneBehavior<TurretActor>();
            this.DisableSceneBehavior<TrapActor>();
            this.DisableSceneBehavior<ThirdPersonController>();
            this.DisableSceneBehavior<PlayerManager>();
            this.DisableSceneBehavior<PlayerActor>();
            this.DisableSceneBehavior<PlayerController>();
            this.DisableSceneBehavior<RemotePlayerActor>();
        }

        // -------------------------------------------------------------------
        // Private
        // -------------------------------------------------------------------
        private void StartEffects()
        {
            bool hasSource = this.HasSelection(this.SourceGroup);
            bool hasTarget = this.HasSelection(this.TargetGroup);
            bool sourceToTargetVfx = hasSource && hasTarget;

            GameObject source = null;
            if (sourceToTargetVfx)
            {
                source = this.GetSelection(this.SourceGroup).First().gameObject;
            }

            IList<ActorBase> targets = this.GetSelection(this.TargetGroup);
            if (targets == null || targets.Count == 0)
            {
                return;
            }

            foreach (ActorBase target in targets)
            {
                if (!sourceToTargetVfx)
                {
                    source = target.gameObject;
                }

                // TODO: - Tick internal timers, advance fake ability state
                foreach (StaticResourceVFXRef resourceRef in this.EffectsToPlay)
                {
                    StartEffect(resourceRef, this.TimingParameters, source, target.gameObject);
                }

#if UNITY_EDITOR
                foreach (StaticDataAbilityRef abilityRef in this.EffectsToPlayFromAbilities)
                {
                    if (!abilityRef.IsValid())
                    {
                        continue;
                    }

                    string assetPath = UnityEditor.AssetDatabase.GUIDToAssetPath(abilityRef.RefGuid);
                    var abilityData = UnityEditor.AssetDatabase.LoadAssetAtPath<StaticDataAbility>(assetPath);
                    if (abilityData == null)
                    {
                        continue;
                    }

                    VfxTimingParameters timing = abilityData.GetAbilityTiming();
                    foreach (StaticResourceVFXRef vfxRef in abilityData.VisualDefinitions)
                    {
                        this.StartEffect(vfxRef, timing, source, target.gameObject);
                    }
                }
#endif
            }
        }

        private void StartEffect(StaticResourceVFXRef resource, VfxTimingParameters timing, GameObject source, GameObject target)
        {
            if (!resource.IsValid())
            {
                return;
            }

            ResourceKey vfxResourceKey = ResourceKey.Create<AbilityVisualDefinition>(resource.GetPath());

            ActiveVfxTicket ticket = VfxSystem.Instance.SpawnVfx(vfxResourceKey, source, target);
            if (ticket != ActiveVfxTicket.Invalid)
            {
                VfxInstance instance = VfxSystem.Instance.GetInstance(ticket);
                instance.Setup(timing);
                this.runningEffects.Add(ticket);
            }
        }

        private void UpdateEffects()
        {
            // check if any effect is still running
            for (var i = 0; i < this.runningEffects.Count; i++)
            {
                if (!VfxSystem.Instance.IsComplete(this.runningEffects[i]))
                {
                    this.IsPlaying = true;
                    return;
                }
            }

            this.runningEffects.Clear();
            this.IsPlaying = false;
        }
    }
}
