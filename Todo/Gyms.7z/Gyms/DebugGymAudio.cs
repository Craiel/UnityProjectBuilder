﻿namespace Assets._TheWall.Scripts.Debug.Gyms
{
    using Data;
    using Emitters;
    using UnityEngine;

    public class DebugGymAudio : DebugGymEmitterBase<DebugAudioEmitter, DebugAudioEmitterPool>
    {
        // -------------------------------------------------------------------
        // Constructor
        // -------------------------------------------------------------------
        public DebugGymAudio()
            : base(AssetResourceKeys.AudioDebugEmitterResourceKey)
        {
        }

        // -------------------------------------------------------------------
        // Protected
        // -------------------------------------------------------------------
        protected override void OnEmit(DebugAudioEmitter instance)
        {
            instance.transform.position = this.Controller.transform.position + (this.Controller.transform.forward * 3);
            instance.Initialize(this.Controller.transform.forward * this.EmitterVelocity);
        }

        protected override bool EmitterUpdate(DebugAudioEmitter instance)
        {
            return !(Time.time > instance.TimeOnInitialize + instance.Lifetime);
        }
    }
}
