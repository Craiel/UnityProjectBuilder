﻿namespace Assets._TheWall.Scripts.Debug.Gyms
{
    using System.Collections.Generic;
    using Defenses;
    using Entity;
    using Entity.Animation;
    using Monster;
    using Player;
    using Player.Controller;
    using UnityEngine;
    using VFX.Instance;

    public class DebugGymAnimation : DebugGymSelectorBase<AnimatedActor>
    {
        private readonly IList<ActiveAnimationTicket> activeAnimations;
        
        private int currentAnimationIndex;
        private float remainingAnimationDelay;

        // -------------------------------------------------------------------
        // Constructor
        // -------------------------------------------------------------------
        public DebugGymAnimation()
        {
            this.activeAnimations = new List<ActiveAnimationTicket>();

            this.AllowGroupSelection = false;
        }

        // -------------------------------------------------------------------
        // Public
        // -------------------------------------------------------------------
        [SerializeField]
        public DebugAnimationData[] AnimationsToPlay;
        
        public bool IsPlaying { get; private set; }
        
        public override void Update()
        {
            if (this.HasActiveSelection)
            {
                // Update the animator here since we disable the game object
                foreach (AnimatedActor actor in this.GetActiveSelection())
                {
                    actor.ActorAnimator.Update();
                }
            }

            // Can't do any other action while playing
            if (this.IsPlaying)
            {
                this.ContinueAnimationPlay();
                return;
            }

            base.Update();
        }

        public void Execute()
        {
            if (!this.HasActiveSelection || this.IsPlaying)
            {
                return;
            }

            if (this.AnimationsToPlay == null || this.AnimationsToPlay.Length == 0)
            {
                return;
            }
            
            this.currentAnimationIndex = 0;
            this.remainingAnimationDelay = this.AnimationsToPlay[0].Delay;
            
            this.IsPlaying = true;
        }

        public void Cancel()
        {
            if (!this.IsPlaying)
            {
                return;
            }

            foreach (ActiveAnimationTicket ticket in this.activeAnimations)
            {
                ticket.Release();
            }

            this.activeAnimations.Clear();
            this.IsPlaying = false;
        }

        // -------------------------------------------------------------------
        // Protected
        // -------------------------------------------------------------------
        protected override void DisableSceneBehaviors()
        {
            this.DisableSceneBehavior<MonsterActor>();
            this.DisableSceneBehavior<TurretActor>();
            this.DisableSceneBehavior<TrapActor>();
            this.DisableSceneBehavior<ThirdPersonController>();
            this.DisableSceneBehavior<PlayerManager>();
            this.DisableSceneBehavior<PlayerActor>();
            this.DisableSceneBehavior<PlayerController>();
            this.DisableSceneBehavior<RemotePlayerActor>();
        }

        // -------------------------------------------------------------------
        // Private
        // -------------------------------------------------------------------
        private void AdvanceAnimationPlay()
        {
            this.currentAnimationIndex++;
            if (this.AnimationsToPlay.Length <= this.currentAnimationIndex)
            {
                this.IsPlaying = false;
                return;
            }

            this.remainingAnimationDelay = this.AnimationsToPlay[this.currentAnimationIndex].Delay;
        }

        private void ContinueAnimationPlay()
        {
            IList<AnimatedActor> targets = this.GetActiveSelection();
            this.remainingAnimationDelay -= Time.deltaTime;
            if (this.remainingAnimationDelay <= 0)
            {
                var definition = this.AnimationsToPlay[this.currentAnimationIndex].Definition;

                foreach (AnimatedActor target in targets)
                {
                    ActiveAnimationTicket ticket = VfxInstanceSegment.InitAnimation(target, definition, 0);
                    if (ticket != null)
                    {
                        this.activeAnimations.Add(ticket);
                    }
                }

                this.AdvanceAnimationPlay();
            }
        }
    }
}
