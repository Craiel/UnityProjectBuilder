﻿namespace Assets._TheWall.Scripts.Debug.Gyms
{
    using CoreGame.Sys;
    using Data;
    using Emitters;
    using Misc;
    using UnityEngine;
    
    public class DebugGymCollision : DebugGymEmitterBase<DebugCollisionEmitter, DebugCollisionEmitterPool>
    {
        // -------------------------------------------------------------------
        // Constructor
        // -------------------------------------------------------------------
        public DebugGymCollision()
            : base(AssetResourceKeys.CollisionDebugEmitterResourceKey)
        {
        }

        // -------------------------------------------------------------------
        // Public
        // -------------------------------------------------------------------
        [SerializeField]
        public DebugWallTest WallTest;

        // -------------------------------------------------------------------
        // Protected
        // -------------------------------------------------------------------
        protected override void OnEmit(DebugCollisionEmitter instance)
        {
            instance.transform.position = this.Controller.transform.position + (this.Controller.transform.forward * 3);
            instance.Initialize(this.Controller.transform.forward * this.EmitterVelocity);
        }

        protected override bool EmitterUpdate(DebugCollisionEmitter emitter)
        {
            this.WallTest.UpdateContainsState(emitter.transform.position.ToMonoVector3());

            return !(Time.time > emitter.TimeOnInitialize + emitter.Lifetime);
        }
    }
}
